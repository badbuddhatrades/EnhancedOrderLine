#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private BadBuddhaCustoms.BadBuddha_Enhanced_OrderLine_Lite[] cacheBadBuddha_Enhanced_OrderLine_Lite;

		
		public BadBuddhaCustoms.BadBuddha_Enhanced_OrderLine_Lite BadBuddha_Enhanced_OrderLine_Lite(int lineThickness, int pTShadeOpacity, int sLShadeOpacity)
		{
			return BadBuddha_Enhanced_OrderLine_Lite(Input, lineThickness, pTShadeOpacity, sLShadeOpacity);
		}


		
		public BadBuddhaCustoms.BadBuddha_Enhanced_OrderLine_Lite BadBuddha_Enhanced_OrderLine_Lite(ISeries<double> input, int lineThickness, int pTShadeOpacity, int sLShadeOpacity)
		{
			if (cacheBadBuddha_Enhanced_OrderLine_Lite != null)
				for (int idx = 0; idx < cacheBadBuddha_Enhanced_OrderLine_Lite.Length; idx++)
					if (cacheBadBuddha_Enhanced_OrderLine_Lite[idx].LineThickness == lineThickness && cacheBadBuddha_Enhanced_OrderLine_Lite[idx].PTShadeOpacity == pTShadeOpacity && cacheBadBuddha_Enhanced_OrderLine_Lite[idx].SLShadeOpacity == sLShadeOpacity && cacheBadBuddha_Enhanced_OrderLine_Lite[idx].EqualsInput(input))
						return cacheBadBuddha_Enhanced_OrderLine_Lite[idx];
			return CacheIndicator<BadBuddhaCustoms.BadBuddha_Enhanced_OrderLine_Lite>(new BadBuddhaCustoms.BadBuddha_Enhanced_OrderLine_Lite(){ LineThickness = lineThickness, PTShadeOpacity = pTShadeOpacity, SLShadeOpacity = sLShadeOpacity }, input, ref cacheBadBuddha_Enhanced_OrderLine_Lite);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.BadBuddhaCustoms.BadBuddha_Enhanced_OrderLine_Lite BadBuddha_Enhanced_OrderLine_Lite(int lineThickness, int pTShadeOpacity, int sLShadeOpacity)
		{
			return indicator.BadBuddha_Enhanced_OrderLine_Lite(Input, lineThickness, pTShadeOpacity, sLShadeOpacity);
		}


		
		public Indicators.BadBuddhaCustoms.BadBuddha_Enhanced_OrderLine_Lite BadBuddha_Enhanced_OrderLine_Lite(ISeries<double> input , int lineThickness, int pTShadeOpacity, int sLShadeOpacity)
		{
			return indicator.BadBuddha_Enhanced_OrderLine_Lite(input, lineThickness, pTShadeOpacity, sLShadeOpacity);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.BadBuddhaCustoms.BadBuddha_Enhanced_OrderLine_Lite BadBuddha_Enhanced_OrderLine_Lite(int lineThickness, int pTShadeOpacity, int sLShadeOpacity)
		{
			return indicator.BadBuddha_Enhanced_OrderLine_Lite(Input, lineThickness, pTShadeOpacity, sLShadeOpacity);
		}


		
		public Indicators.BadBuddhaCustoms.BadBuddha_Enhanced_OrderLine_Lite BadBuddha_Enhanced_OrderLine_Lite(ISeries<double> input , int lineThickness, int pTShadeOpacity, int sLShadeOpacity)
		{
			return indicator.BadBuddha_Enhanced_OrderLine_Lite(input, lineThickness, pTShadeOpacity, sLShadeOpacity);
		}

	}
}

#endregion
